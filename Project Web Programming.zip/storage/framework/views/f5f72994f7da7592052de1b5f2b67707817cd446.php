

<?php $__env->startSection('title', 'Xiao Ding Dong'); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="col-md-12 mx-auto">
        <h1 class="text-warning">你的购物车 | Your Cart</h1>
        <?php if($items->isEmpty()): ?>
        <div class="container text-warning" style="background-color: rgb(37, 37, 37); height:40px; text-align:center;"><h5>Your Cart is empty.....</h5></div>
        <?php else: ?>
        <table class="table">
          <thead style="background-color:rgb(22, 22, 22)">
            <tr>
              <th scope="col"class="text-warning text-center" style="width: 30%;">Food</th>
              <th scope="col"class="text-warning text-center" style="width: 10%;">Price</th>
              <th scope="col"class="text-warning text-center" style="width: 20%;">Quantity</th>
              <th scope="col"class="text-warning text-center" style="width: 20%;">Total</th>
              <th scope="col"class="text-warning text-center" style="width: 20%;"></th>
            </tr>
          </thead>
          <tbody style="background-color:rgb(72, 72, 72)">
            <?php
                  $sum=0;
            ?>
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
            <td class="text-white text-center"><?php echo e($item->food->item_name); ?></td>
            <td class="text-white text-center">$<?php echo e($item->food->item_price); ?></td>
            <td class="text-white text-center">
              <input type="number" value = <?php echo e($item->quantity); ?> min="1" class="form-control" name="quantity" style="width: 70px">
            </td>
            <td class="text-white text-center">$<?php echo e($item->quantity * $item->food->item_price); ?></td>
            <td class="text-white text-center">

            <form action = "<?php echo e(route('remove', $item->food_id)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button class="btn-btn secondary text-warning" style="background-color: rgb(22, 22, 22)">Remove</button>
            <form>
            </td>
          </tr>
          <?php
              $sum += $item->quantity * $item->food->item_price;
          ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
         <h1 style="color: white; text-align:right;">Total Price: $<?php echo e($sum); ?></h1>
         <div style="text-align: right"><a href="/checkout" style="text-decoration: none" class="btn btn-secondary text-warning">checkout</a></div>
        <?php endif; ?>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./components/mainNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DARREN ENGELBERT\Desktop\BINUS\SEM5\Web Programming\Project Web Programming\Project_Lab\resources\views/Cart.blade.php ENDPATH**/ ?>